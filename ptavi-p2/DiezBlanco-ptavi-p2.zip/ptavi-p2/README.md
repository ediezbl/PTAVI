# ptavi-p2
Repositorio de la práctica 2 de PTAVI

Desde 2016-2017 en Python 3
